<img style="height: 80px; width:250px;" src="{{ asset('img/logo.png') }}" alt="logo">
