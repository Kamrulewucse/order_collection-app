<audio id="notification-success-audio">
    <source src="{{ asset('img/success.wav') }}" type="audio/wav">
    Your browser does not support the audio element.
</audio>
<audio id="notification-error-audio">
    <source src="{{ asset('img/error.wav') }}" type="audio/wav">
    Your browser does not support the audio element.
</audio>
<audio id="add_more_sound" style="display: none">
    <source src="{{ asset('img/add.mp3') }}" type="audio/mpeg">
    Your browser does not support the audio element.
</audio>
<audio id="remove_sound" style="display: none">
    <source src="{{ asset('img/remove.mp3') }}" type="audio/mpeg">
    Your browser does not support the audio element.
</audio>
