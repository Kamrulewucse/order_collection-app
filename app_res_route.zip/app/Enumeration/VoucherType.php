<?php
namespace App\Enumeration;

class VoucherType
{
    public static $JOURNAL_VOUCHER = 1;
    public static $PAYMENT_VOUCHER = 2;
    public static $COLLECTION_VOUCHER = 3;
    public static $CONTRA_VOUCHER = 4;
}
