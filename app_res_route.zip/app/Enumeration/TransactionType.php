<?php
namespace App\Enumeration;

class  TransactionType
{
    public static $DEBIT = 1;
    public static $CREDIT = 2;
}
